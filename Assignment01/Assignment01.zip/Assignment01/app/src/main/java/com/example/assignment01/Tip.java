package com.example.assignment01;

public class Tip {

    double percentage;

    public Tip() {}

    public Tip(double percentage) {
        this.percentage = percentage;
    }

    public double getPercentage() {
        return percentage;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }
}
